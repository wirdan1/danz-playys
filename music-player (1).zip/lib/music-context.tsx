"use client"

import { createContext, useContext, useState, type ReactNode } from "react"
import { musicData } from "./music-data"

type Song = (typeof musicData)[0]

interface MusicContextType {
  currentSongIndex: number
  setCurrentSongIndex: (index: number) => void
  isPlaying: boolean
  setIsPlaying: (isPlaying: boolean) => void
  playSong: (song: Song) => void
}

const MusicContext = createContext<MusicContextType | undefined>(undefined)

export function MusicProvider({ children }: { children: ReactNode }) {
  const [currentSongIndex, setCurrentSongIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)

  const playSong = (song: Song) => {
    const songIndex = musicData.findIndex((s) => s.title === song.title && s.artist === song.artist)

    if (songIndex !== -1) {
      setCurrentSongIndex(songIndex)
      setIsPlaying(true)
    }
  }

  return (
    <MusicContext.Provider
      value={{
        currentSongIndex,
        setCurrentSongIndex,
        isPlaying,
        setIsPlaying,
        playSong,
      }}
    >
      {children}
    </MusicContext.Provider>
  )
}

export function useMusic() {
  const context = useContext(MusicContext)
  if (context === undefined) {
    throw new Error("useMusic must be used within a MusicProvider")
  }
  return context
}

