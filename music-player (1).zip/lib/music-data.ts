export const musicData = [
  {
    title: "Damon Vacation",
    artist: "Damon Empero",
    audioUrl:
      "https://files.catbox.moe/c5edok.mp3",
    imageUrl: "https://i.ytimg.com/vi/ALzvSPXmeh8/hq720.jpg",
  },
  {
    title: "Blinding Lights",
    artist: "The Weeknd",
    audioUrl: "https://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Sevish_-__nbsp_.mp3",
    imageUrl: "/placeholder.svg?height=240&width=240",
  },
  {
    title: "Dance Monkey",
    artist: "Tones and I",
    audioUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/Epoq-Lepidoptera.ogg",
    imageUrl: "/placeholder.svg?height=240&width=240",
  },
  {
    title: "Watermelon Sugar",
    artist: "Harry Styles",
    audioUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/Evillaugh.ogg",
    imageUrl: "/placeholder.svg?height=240&width=240",
  },
  {
    title: "Don't Start Now",
    artist: "Dua Lipa",
    audioUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week7-brrring.m4a",
    imageUrl: "/placeholder.svg?height=240&width=240",
  },
]

