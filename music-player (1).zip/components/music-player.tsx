"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import { Play, Pause, SkipBack, SkipForward, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"
import { musicData } from "@/lib/music-data"
import { useMusic } from "@/lib/music-context"

export default function MusicPlayer() {
  const { currentSongIndex, setCurrentSongIndex, isPlaying, setIsPlaying } = useMusic()
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(0.7)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const currentSong = musicData[currentSongIndex]

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch((error) => {
          console.error("Error playing audio:", error)
          setIsPlaying(false)
        })
      } else {
        audioRef.current.pause()
      }
    }
  }, [isPlaying, currentSongIndex, setIsPlaying])

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume
    }
  }, [volume])

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying)
  }

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime)
      setDuration(audioRef.current.duration)
    }
  }

  const handleSliderChange = (value: number[]) => {
    if (audioRef.current) {
      audioRef.current.currentTime = value[0]
      setCurrentTime(value[0])
    }
  }

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0]
    setVolume(newVolume)
  }

  const handlePrevious = () => {
    setCurrentSongIndex((prev) => (prev === 0 ? musicData.length - 1 : prev - 1))
    setIsPlaying(true)
  }

  const handleNext = () => {
    setCurrentSongIndex((prev) => (prev === musicData.length - 1 ? 0 : prev + 1))
    setIsPlaying(true)
  }

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`
  }

  return (
    <Card className="w-full max-w-3xl mx-auto mb-8">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row gap-6 items-center">
          <div className="relative w-full max-w-[240px] aspect-square rounded-md overflow-hidden">
            <Image
              src={currentSong.imageUrl || "/placeholder.svg"}
              alt={`${currentSong.title} by ${currentSong.artist}`}
              fill
              className="object-cover"
            />
          </div>

          <div className="flex-1 w-full">
            <h2 className="text-2xl font-bold">{currentSong.title}</h2>
            <p className="text-muted-foreground mb-4">{currentSong.artist}</p>

            <audio
              ref={audioRef}
              src={currentSong.audioUrl}
              onTimeUpdate={handleTimeUpdate}
              onEnded={handleNext}
              onLoadedMetadata={handleTimeUpdate}
            />

            <div className="space-y-4">
              <Slider
                value={[currentTime]}
                max={duration || 100}
                step={0.1}
                onValueChange={handleSliderChange}
                className="w-full"
              />

              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>

              <div className="flex items-center justify-center gap-4">
                <Button variant="ghost" size="icon" onClick={handlePrevious}>
                  <SkipBack />
                </Button>
                <Button variant="default" size="icon" className="h-12 w-12 rounded-full" onClick={handlePlayPause}>
                  {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-1" />}
                </Button>
                <Button variant="ghost" size="icon" onClick={handleNext}>
                  <SkipForward />
                </Button>
              </div>

              <div className="flex items-center gap-2">
                <Volume2 className="h-4 w-4 text-muted-foreground" />
                <Slider value={[volume]} max={1} step={0.01} onValueChange={handleVolumeChange} className="w-24" />
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

