"use client"

import { Input } from "@/components/ui/input"

import { useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

// Mock comments data - in a real app, this would come from a database
const initialComments = [
  {
    id: 1,
    name: "Alex Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    content: "This player is amazing! Love the interface and song selection.",
    date: "2 days ago",
  },
  {
    id: 2,
    name: "Sarah Miller",
    avatar: "/placeholder.svg?height=40&width=40",
    content: "Could you add more songs from indie artists? Otherwise, great work!",
    date: "1 week ago",
  },
]

export default function CommentSection() {
  const [comments, setComments] = useState(initialComments)
  const [newComment, setNewComment] = useState("")
  const [userName, setUserName] = useState("")
  const { toast } = useToast()

  const handleSubmitComment = () => {
    if (!newComment.trim() || !userName.trim()) {
      toast({
        title: "Error",
        description: "Please enter your name and comment",
        variant: "destructive",
      })
      return
    }

    const comment = {
      id: comments.length + 1,
      name: userName,
      avatar: "/placeholder.svg?height=40&width=40",
      content: newComment,
      date: "Just now",
    }

    setComments([comment, ...comments])
    setNewComment("")

    toast({
      title: "Comment added",
      description: "Your comment has been posted successfully",
    })
  }

  return (
    <Card className="w-full max-w-3xl mx-auto mb-8">
      <CardHeader>
        <CardTitle>Comments</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="name" className="text-sm font-medium mb-1 block">
                  Your Name
                </label>
                <Input
                  id="name"
                  placeholder="Enter your name"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                />
              </div>
            </div>
            <div>
              <label htmlFor="comment" className="text-sm font-medium mb-1 block">
                Your Comment
              </label>
              <Textarea
                id="comment"
                placeholder="Share your thoughts..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                rows={3}
              />
            </div>
            <Button onClick={handleSubmitComment}>Post Comment</Button>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Recent Comments ({comments.length})</h3>
            {comments.map((comment) => (
              <div key={comment.id} className="flex gap-4 p-4 border rounded-lg">
                <Avatar>
                  <AvatarImage src={comment.avatar} alt={comment.name} />
                  <AvatarFallback>{comment.name.substring(0, 2)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-1">
                    <h4 className="font-medium">{comment.name}</h4>
                    <span className="text-xs text-muted-foreground">{comment.date}</span>
                  </div>
                  <p className="text-sm">{comment.content}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

