"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Trash2 } from "lucide-react"

// Mock comments data - in a real app, this would come from a database
const initialComments = [
  {
    id: 1,
    name: "Alex Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    content: "This player is amazing! Love the interface and song selection.",
    date: "2 days ago",
  },
  {
    id: 2,
    name: "Sarah Miller",
    avatar: "/placeholder.svg?height=40&width=40",
    content: "Could you add more songs from indie artists? Otherwise, great work!",
    date: "1 week ago",
  },
  {
    id: 3,
    name: "Michael Brown",
    avatar: "/placeholder.svg?height=40&width=40",
    content: "The search feature works really well. I found all my favorite songs quickly.",
    date: "2 weeks ago",
  },
  {
    id: 4,
    name: "Emily Davis",
    avatar: "/placeholder.svg?height=40&width=40",
    content: "I love how clean the interface is. Very user-friendly!",
    date: "3 weeks ago",
  },
]

export default function CommentsList() {
  const [comments, setComments] = useState(initialComments)

  const handleDeleteComment = (id: number) => {
    setComments(comments.filter((comment) => comment.id !== id))
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">All Comments ({comments.length})</h3>
      </div>

      {comments.length > 0 ? (
        <div className="space-y-4">
          {comments.map((comment) => (
            <div key={comment.id} className="flex gap-4 p-4 border rounded-lg">
              <Avatar>
                <AvatarImage src={comment.avatar} alt={comment.name} />
                <AvatarFallback>{comment.name.substring(0, 2)}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between items-center mb-1">
                  <h4 className="font-medium">{comment.name}</h4>
                  <span className="text-xs text-muted-foreground">{comment.date}</span>
                </div>
                <p className="text-sm">{comment.content}</p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="text-muted-foreground hover:text-destructive"
                onClick={() => handleDeleteComment(comment.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-muted-foreground">No comments to display</div>
      )}
    </div>
  )
}

