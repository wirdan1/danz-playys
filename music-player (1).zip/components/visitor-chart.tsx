"use client"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Line, LineChart, CartesianGrid, XAxis, YAxis } from "recharts"

// Mock visitor data - in a real app, this would come from a database
const visitorData = [
  { date: "Jan 1", visitors: 0 },
  { date: "Jan 2", visitors: 12 },
  { date: "Jan 3", visitors: 28 },
  { date: "Jan 4", visitors: 45 },
  { date: "Jan 5", visitors: 67 },
  { date: "Jan 6", visitors: 93 },
  { date: "Jan 7", visitors: 127 },
  { date: "Jan 8", visitors: 159 },
  { date: "Jan 9", visitors: 192 },
  { date: "Jan 10", visitors: 231 },
]

export default function VisitorChart() {
  return (
    <ChartContainer
      config={{
        visitors: {
          label: "Visitors",
          color: "hsl(var(--chart-1))",
        },
      }}
      className="w-full aspect-[16/9]"
    >
      <LineChart data={visitorData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="date" tick={{ fontSize: 12 }} tickLine={false} />
        <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
        <ChartTooltip content={<ChartTooltipContent indicator="line" nameKey="visitors" labelKey="date" />} />
        <Line
          type="monotone"
          dataKey="visitors"
          stroke="var(--color-visitors)"
          strokeWidth={2}
          dot={{ r: 4 }}
          activeDot={{ r: 6 }}
        />
      </LineChart>
    </ChartContainer>
  )
}

