import Link from "next/link"

export default function Footer() {
  return (
    <footer className="py-6 text-center">
      <p className="text-sm text-muted-foreground">
        Created by <span className="font-medium">Danz-dev</span> |
        <Link href="/login" className="ml-1 underline underline-offset-4 hover:text-primary">
          Developer Login
        </Link>
      </p>
    </footer>
  )
}

