"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { musicData } from "@/lib/music-data"
import Image from "next/image"
import { useMusic } from "@/lib/music-context"

export default function SearchBar() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<typeof musicData>([])
  const [isSearching, setIsSearching] = useState(false)
  const { playSong } = useMusic()

  const handleSearch = () => {
    if (!query.trim()) {
      setResults([])
      setIsSearching(false)
      return
    }

    const filteredResults = musicData.filter(
      (song) =>
        song.title.toLowerCase().includes(query.toLowerCase()) ||
        song.artist.toLowerCase().includes(query.toLowerCase()),
    )

    setResults(filteredResults)
    setIsSearching(true)
  }

  const handleSongClick = (song: (typeof musicData)[0]) => {
    playSong(song)
    setIsSearching(false) // Optional: hide search results after selection
  }

  return (
    <div className="mb-8 w-full max-w-3xl mx-auto">
      <div className="flex gap-2">
        <Input
          placeholder="Search by artist or title..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          className="flex-1"
        />
        <Button onClick={handleSearch}>
          <Search className="h-4 w-4 mr-2" />
          Search
        </Button>
      </div>

      {isSearching && (
        <Card className="mt-4">
          <CardContent className="p-4">
            <h3 className="font-medium mb-2">Search Results ({results.length})</h3>
            {results.length > 0 ? (
              <ul className="space-y-2">
                {results.map((song, index) => (
                  <li
                    key={index}
                    className="flex items-center gap-3 p-2 hover:bg-muted rounded-md cursor-pointer transition-colors"
                    onClick={() => handleSongClick(song)}
                  >
                    <div className="relative w-10 h-10 rounded overflow-hidden">
                      <Image src={song.imageUrl || "/placeholder.svg"} alt={song.title} fill className="object-cover" />
                    </div>
                    <div>
                      <p className="font-medium">{song.title}</p>
                      <p className="text-sm text-muted-foreground">{song.artist}</p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground">No results found</p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

