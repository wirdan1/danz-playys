import MusicPlayer from "@/components/music-player"
import SearchBar from "@/components/search-bar"
import CommentSection from "@/components/comment-section"
import Footer from "@/components/footer"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted">
      <header className="container mx-auto px-4 py-4 flex justify-end">
        <ThemeToggle />
      </header>
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center mb-8">Music Player</h1>
        <SearchBar />
        <MusicPlayer />
        <CommentSection />
        <Footer />
      </main>
    </div>
  )
}

